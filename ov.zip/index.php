<?php
error_reporting(0);
require_once 'prsr.php';

$status = new OpenVPNStatus();
$status->loadFromFile('/run/openvpn/server.status');
$status->parse();


$updated = clone($status->getUpdated());
$updated->setTimezone(new DateTimeZone('Europe/Belgrade'));
$updated = $updated->format(DATE_RFC1036);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>VPN Status</title>
    <style>
        .latency {
            display: none;
        }
    </style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
</head>
<body>
<div class="container">
    <h1><pre style="background-color: black; color: white;padding: 3px;3px; display: inline-block;">>_
 __ __ _____ _____ _ __ __ 
|  |  |  _  |   | |_|  |  |
|  |  |   __| | | | |-   -|
 \___/|__|  |_|___|_|__|__|
 <font color="green">
 <b>Crypt loaded...[OK]</b>
 <b>App loaded.....[OK]</b>
 </font></pre></h1>
    <h4>Updated <?= $updated ?></h4>
 
        <?php /** @var OpenVPNClient $client */
        foreach ($status->getClients() as $client) : ?>
	
          
		
		
           
                    <ul class="list-group">
					
					
						<div class="bs-example" data-example-id="hoverable-table">
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Data</th>
            </tr>
        </thead>
        <tbody>
                        <?php 
						function pp($arr){
    if (is_array($arr)){
        foreach ($arr as $key=>$val){
            if (is_array($val)){
                $retStr .=  " ".pp($val) . ' ';
            }else{
				if($key == "icon")
				{
                $retStr .='<img src="img/' . $val . '.png">';
				}
				else
				{
                $retStr .=  $val . '';
				}	
            }
        }
    }
    return $retStr;
}
						
					?>
						
						 <tr>
              
                <td><?php echo pp($client->getReadableArray()); ?></td>
            </tr>
						
						
                          
                        
                    </ul>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

        </tbody>
    </table>
</div>
		
</div>
<script>
    $('.latency').each(function () {
        var elem = $(this);
        var ip = elem.data('ip');
        console.log('IP: ' + ip);
      
        $.get('ping.php', {'ip': ip}, function(data){
            if (data.length > 0) {
                elem.html(data + ' ms');
            }
            else {
                elem.html('NR');
            }
        }).fail(function() {
            elem.html('ERR');
        });
    });
</script>
</body>
</html>